%   Multi-objective Search Manager Framework for Big Data Optimization Problems
%   Developed in MATLAB R2017a
%   Author and programmer: Yousef Abdi
%   e-Mail: yousef.abdi@gmail.com
            y.abdi@tabrizu.ac.ir

%   Main paper:
%   Y. Abdi, M.R. Feizi-Derakhshi,
%   Hybrid Multi-objective Evolutionary Algorithm based on Search Manager Framework for Big Data Optimization Problems
%   Applied Soft Computing
%   DOI: 10.1016/j.asoc.2019.105991


--= The script is run by SearchManager script. =--